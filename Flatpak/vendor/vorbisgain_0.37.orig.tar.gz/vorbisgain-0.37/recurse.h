#ifndef VG_RECURSE_H
#define VG_RECURSE_H

#ifdef ENABLE_RECURSIVE

#include "vorbisgain.h"

extern int process_argument(const char* path, SETTINGS* settings);

#endif /* ENABLE_RECURSIVE */

#endif /* VG_RECURSE_H */
