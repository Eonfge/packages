# Opus Audio Tools

[![Travis Build Status](https://travis-ci.org/xiph/opus-tools.svg?branch=master)](https://travis-ci.org/xiph/opus-tools)
[![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/xiph/opus-tools?branch=master&svg=true)](https://ci.appveyor.com/project/rillian/opus-tools)

This is opus-tools, a set of tools to encode, inspect, and decode
audio in the Opus format.

For more information on Opus see https://www.opus-codec.org/
